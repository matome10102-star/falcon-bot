export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();

  try {
    const { pair, score, verdict, rsi, pattern, direction, entry, sl, tp, slPips, tpPips, riskAmount, accountSize } = req.body;
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: "You are an expert forex trading analyst specializing in the Falcon Strategy. Give sharp, direct, professional trade commentary. Be concise — max 4 sentences. Never promise guaranteed profits.",
        messages: [{ role: "user", content: `Analyze this Falcon Strategy signal for ${pair}: Score ${score}/100, Verdict: ${verdict}, RSI: ${rsi}, Pattern: ${pattern||"None"}, Direction: ${direction}, Entry: ${entry}, SL: ${sl}, TP: ${tp}, SL pips: ${slPips}, TP pips: ${tpPips}, Risk: $${riskAmount} on $${accountSize} account. Give brief professional commentary.` }],
      }),
    });
    if (!response.ok) return res.status(500).json({ error: "Anthropic API error" });
    const data = await response.json();
    return res.status(200).json({ commentary: data.content?.map(b => b.text || "").join("") || "" });
  } catch (err) {
    return res.status(500).json({ error: "Server error" });
  }
}
