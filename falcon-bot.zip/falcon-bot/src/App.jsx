import { useState } from "react";

// ─── Falcon Strategy Logic ───────────────────────────────────────────────────

function calcEMA(data, period) {
  const k = 2 / (period + 1);
  let ema = data[0];
  const result = [ema];
  for (let i = 1; i < data.length; i++) {
    ema = data[i] * k + ema * (1 - k);
    result.push(ema);
  }
  return result;
}

function calcRSI(data, period = 14) {
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const diff = data[i] - data[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  let avgGain = gains / period, avgLoss = losses / period;
  const result = new Array(period).fill(null);
  result.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));
  for (let i = period + 1; i < data.length; i++) {
    const diff = data[i] - data[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(diff, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-diff, 0)) / period;
    result.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));
  }
  return result;
}

function detectCandlePattern(candles) {
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  const body = Math.abs(last.close - last.open);
  const range = last.high - last.low;
  const lowerWick = Math.min(last.open, last.close) - last.low;
  const upperWick = last.high - Math.max(last.open, last.close);
  if (lowerWick > body * 2 && lowerWick > upperWick * 2 && range > 0)
    return { name: "Bullish Pin Bar", direction: "BULL" };
  if (last.close > last.open && prev.close < prev.open &&
    last.close > prev.open && last.open < prev.close)
    return { name: "Bullish Engulfing", direction: "BULL" };
  if (upperWick > body * 2 && upperWick > lowerWick * 2 && range > 0)
    return { name: "Bearish Pin Bar", direction: "BEAR" };
  if (last.close < last.open && prev.close > prev.open &&
    last.close < prev.open && last.open > prev.close)
    return { name: "Bearish Engulfing", direction: "BEAR" };
  if (body < range * 0.1) return { name: "Doji (Indecision)", direction: "NEUTRAL" };
  return null;
}

function analyzeFalcon(pair, candles, accountSize, riskPct) {
  const closes = candles.map(c => c.close);
  const ema50 = calcEMA(closes, 50);
  const ema200 = calcEMA(closes, 200);
  const rsi = calcRSI(closes, 14);
  const lastClose = closes[closes.length - 1];
  const lastEMA50 = ema50[ema50.length - 1];
  const lastEMA200 = ema200[ema200.length - 1];
  const lastRSI = rsi[rsi.length - 1];
  const pattern = detectCandlePattern(candles);
  const bullTrend = lastClose > lastEMA50 && lastEMA50 > lastEMA200;
  const bearTrend = lastClose < lastEMA50 && lastEMA50 < lastEMA200;
  const trendDir = bullTrend ? "BULLISH" : bearTrend ? "BEARISH" : "RANGING";
  const nearEMA50 = Math.abs(lastClose - lastEMA50) / lastEMA50 < 0.003;
  const rsiBull = lastRSI >= 35 && lastRSI <= 55;
  const rsiBear = lastRSI >= 45 && lastRSI <= 65;
  const rsiOK = bullTrend ? rsiBull : bearTrend ? rsiBear : false;
  const patternOK = pattern && ((bullTrend && pattern.direction === "BULL") || (bearTrend && pattern.direction === "BEAR"));
  let score = 0;
  const signals = [];
  if (bullTrend || bearTrend) { score += 30; signals.push({ label: `Trend: ${trendDir}`, ok: true }); }
  else signals.push({ label: "No clear trend (ranging)", ok: false });
  if (nearEMA50) { score += 25; signals.push({ label: "Price at 50 EMA pullback zone", ok: true }); }
  else signals.push({ label: "Price not at 50 EMA zone", ok: false });
  if (rsiOK) { score += 20; signals.push({ label: `RSI at ${lastRSI?.toFixed(1)} — momentum OK`, ok: true }); }
  else signals.push({ label: `RSI at ${lastRSI?.toFixed(1)} — not ideal`, ok: false });
  if (patternOK) { score += 25; signals.push({ label: `Pattern: ${pattern.name}`, ok: true }); }
  else if (pattern) signals.push({ label: `Pattern: ${pattern.name} (wrong direction)`, ok: false });
  else signals.push({ label: "No reversal candle pattern", ok: false });
  const pipSize = pair.includes("JPY") ? 0.01 : 0.0001;
  const swingLow = Math.min(...candles.slice(-10).map(c => c.low));
  const swingHigh = Math.max(...candles.slice(-10).map(c => c.high));
  const lastCandle = candles[candles.length - 1];
  let entry, sl, tp, direction;
  if (bullTrend) {
    direction = "BUY";
    entry = lastCandle.high + pipSize * 3;
    sl = swingLow - pipSize * 5;
    tp = entry + (entry - sl) * 2;
  } else {
    direction = "SELL";
    entry = lastCandle.low - pipSize * 3;
    sl = swingHigh + pipSize * 5;
    tp = entry - (sl - entry) * 2;
  }
  const slPips = Math.abs(entry - sl) / pipSize;
  const riskAmount = (accountSize * riskPct) / 100;
  const lotSize = riskAmount / (slPips * 1 * 100);
  return {
    pair, score, trendDir, lastClose, lastEMA50, lastEMA200, lastRSI,
    pattern, signals, direction, entry, sl, tp,
    slPips: slPips.toFixed(1),
    tpPips: (Math.abs(tp - entry) / pipSize).toFixed(1),
    lotSize: Math.max(0.01, lotSize).toFixed(2),
    riskAmount: riskAmount.toFixed(2),
    verdict: score >= 80 ? "STRONG SIGNAL" : score >= 60 ? "WEAK SIGNAL" : "NO TRADE",
    bullTrend, bearTrend,
    ema50, ema200,
  };
}

function generateCandles(pair, trend = "bull", n = 220) {
  const bases = { "EUR/USD": 1.0850, "GBP/USD": 1.2700, "USD/JPY": 149.50, "AUD/USD": 0.6550, "USD/CAD": 1.3600 };
  let price = bases[pair] || 1.1000;
  const pipSize = pair.includes("JPY") ? 0.01 : 0.0001;
  const candles = [];
  for (let i = 0; i < n; i++) {
    const trendBias = trend === "bull" ? 0.0002 : trend === "bear" ? -0.0002 : 0;
    const move = (Math.random() - 0.48) * pipSize * 15 + trendBias;
    const open = price, close = price + move;
    const high = Math.max(open, close) + Math.random() * pipSize * 8;
    const low = Math.min(open, close) - Math.random() * pipSize * 8;
    candles.push({ open, high, low, close });
    price = close;
  }
  const ema50End = calcEMA(candles.map(c => c.close), 50).slice(-1)[0];
  const last = candles[candles.length - 1];
  const pullbackClose = ema50End + (trend === "bull" ? pipSize * 2 : -pipSize * 2);
  candles[candles.length - 1] = {
    open: last.open, close: pullbackClose,
    high: Math.max(last.open, pullbackClose) + pipSize * 5,
    low: Math.min(last.open, pullbackClose) - pipSize * 12,
  };
  return candles;
}

function MiniChart({ candles, ema50, ema200, entry, sl, tp }) {
  const w = 340, h = 160;
  const recent = candles.slice(-40);
  const e50 = ema50.slice(-40);
  const e200 = ema200.slice(-40);
  const allPrices = [...recent.flatMap(c => [c.high, c.low]), ...e50, ...e200, entry, sl, tp].filter(Boolean);
  const minP = Math.min(...allPrices), maxP = Math.max(...allPrices);
  const range = maxP - minP || 0.001;
  const px = i => (i / (recent.length - 1)) * (w - 20) + 10;
  const py = p => h - 10 - ((p - minP) / range) * (h - 20);
  return (
    <svg width={w} height={h} style={{ background: "#050a08", borderRadius: 4, display: "block" }}>
      {[0.25, 0.5, 0.75].map(r => <line key={r} x1="0" y1={h * r} x2={w} y2={h * r} stroke="#0f1f0f" strokeWidth="1" />)}
      {tp && <line x1="0" y1={py(tp)} x2={w} y2={py(tp)} stroke="#00f5c4" strokeWidth="1" strokeDasharray="4,3" opacity="0.7" />}
      {entry && <line x1="0" y1={py(entry)} x2={w} y2={py(entry)} stroke="#fde047" strokeWidth="1" strokeDasharray="4,3" opacity="0.8" />}
      {sl && <line x1="0" y1={py(sl)} x2={w} y2={py(sl)} stroke="#f87171" strokeWidth="1" strokeDasharray="4,3" opacity="0.7" />}
      <path d={e200.map((v, i) => `${i === 0 ? "M" : "L"}${px(i)},${py(v)}`).join(" ")} fill="none" stroke="#f87171" strokeWidth="1.5" opacity="0.7" />
      <path d={e50.map((v, i) => `${i === 0 ? "M" : "L"}${px(i)},${py(v)}`).join(" ")} fill="none" stroke="#7ed6f7" strokeWidth="1.5" opacity="0.8" />
      {recent.map((c, i) => {
        const bull = c.close >= c.open;
        const cx = px(i), bodyTop = py(Math.max(c.open, c.close)), bodyBot = py(Math.min(c.open, c.close));
        return (
          <g key={i}>
            <line x1={cx} y1={py(c.high)} x2={cx} y2={py(c.low)} stroke={bull ? "#4ade80" : "#f87171"} strokeWidth="1" />
            <rect x={cx - 3} y={bodyTop} width={6} height={Math.max(1, bodyBot - bodyTop)} fill={bull ? "#4ade80" : "#f87171"} opacity="0.9" />
          </g>
        );
      })}
      <text x={w - 4} y={py(tp) - 3} textAnchor="end" fill="#00f5c4" fontSize="8">TP</text>
      <text x={w - 4} y={py(entry) - 3} textAnchor="end" fill="#fde047" fontSize="8">ENTRY</text>
      <text x={w - 4} y={py(sl) + 9} textAnchor="end" fill="#f87171" fontSize="8">SL</text>
    </svg>
  );
}

function Journal({ journal, setJournal }) {
  const wins = journal.filter(t => t.result === "WIN").length;
  const losses = journal.filter(t => t.result === "LOSS").length;
  const totalPnl = journal.reduce((s, t) => s + (t.pnl || 0), 0);
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12, marginBottom: 24 }}>
        {[["TOTAL TRADES", journal.length, "#7ed6f7"], ["WINS", wins, "#4ade80"], ["LOSSES", losses, "#f87171"],
          ["WIN RATE", journal.length ? `${((wins / journal.length) * 100).toFixed(0)}%` : "—", "#fde047"]].map(([l, v, c]) => (
          <div key={l} style={{ background: "#081008", border: "1px solid #1a2a1a", padding: 14, borderRadius: 4, textAlign: "center" }}>
            <div style={{ fontSize: "0.55rem", color: "#3a5a3a", letterSpacing: "0.2em", marginBottom: 6 }}>{l}</div>
            <div style={{ fontSize: "1.4rem", color: c, fontWeight: "bold" }}>{v}</div>
          </div>
        ))}
      </div>
      <div style={{ background: "#081008", border: `1px solid ${totalPnl >= 0 ? "#4ade80" : "#f87171"}`, padding: "14px 20px", borderRadius: 4, marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: "0.7rem", color: "#3a5a3a", letterSpacing: "0.2em" }}>TOTAL P&L</span>
        <span style={{ fontSize: "1.2rem", color: totalPnl >= 0 ? "#4ade80" : "#f87171", fontWeight: "bold" }}>{totalPnl >= 0 ? "+" : ""}${totalPnl.toFixed(2)}</span>
      </div>
      {journal.length === 0 ? (
        <div style={{ textAlign: "center", color: "#3a5a3a", fontSize: "0.8rem", padding: 40 }}>No trades logged yet.</div>
      ) : [...journal].reverse().map((t, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, background: "#050a08", border: "1px solid #1a2a1a", padding: "12px 16px", borderRadius: 4, marginBottom: 8 }}>
          <div style={{ width: 50, fontSize: "0.65rem", color: t.direction === "BUY" ? "#4ade80" : "#f87171", fontWeight: "bold" }}>{t.direction}</div>
          <div style={{ flex: 1, fontSize: "0.75rem", color: "#6a9a6a" }}>{t.pair}</div>
          <div style={{ fontSize: "0.7rem", color: "#4a6a4a" }}>Entry: {t.entry?.toFixed(4)}</div>
          {t.result ? (
            <div style={{ fontSize: "0.75rem", color: t.result === "WIN" ? "#4ade80" : "#f87171", fontWeight: "bold", width: 60, textAlign: "right" }}>
              {t.result === "WIN" ? "+" : "-"}${Math.abs(t.pnl).toFixed(2)}
            </div>
          ) : (
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => setJournal(j => j.map((x, idx) => j.length - 1 - i === idx ? { ...x, result: "WIN", pnl: parseFloat(x.riskAmount) * 2 } : x))}
                style={{ background: "#4ade8030", border: "1px solid #4ade80", color: "#4ade80", fontSize: "0.6rem", padding: "4px 8px", cursor: "pointer", borderRadius: 2, fontFamily: "inherit" }}>WIN</button>
              <button onClick={() => setJournal(j => j.map((x, idx) => j.length - 1 - i === idx ? { ...x, result: "LOSS", pnl: -parseFloat(x.riskAmount) } : x))}
                style={{ background: "#f8717130", border: "1px solid #f87171", color: "#f87171", fontSize: "0.6rem", padding: "4px 8px", cursor: "pointer", borderRadius: 2, fontFamily: "inherit" }}>LOSS</button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

const PAIRS = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD"];
const verdictColor = v => v === "STRONG SIGNAL" ? "#4ade80" : v === "WEAK SIGNAL" ? "#fde047" : "#f87171";

export default function FalconBot() {
  const [tab, setTab] = useState("analyzer");
  const [selectedPair, setSelectedPair] = useState("EUR/USD");
  const [accountSize, setAccountSize] = useState(1000);
  const [riskPct, setRiskPct] = useState(1);
  const [analysis, setAnalysis] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [scanResults, setScanResults] = useState([]);
  const [journal, setJournal] = useState([]);
  const [aiComment, setAiComment] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  const runAnalysis = async (pair = selectedPair) => {
    setScanning(true); setAnalysis(null); setAiComment("");
    await new Promise(r => setTimeout(r, 700));
    const trend = Math.random() > 0.5 ? "bull" : "bear";
    const c = generateCandles(pair, trend);
    const result = analyzeFalcon(pair, c, accountSize, riskPct);
    setAnalysis(result);
    setScanning(false);

    // Call our SECURE serverless backend — API key is never in the browser
    setAiLoading(true);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pair, score: result.score, verdict: result.verdict,
          rsi: result.lastRSI?.toFixed(1), pattern: result.pattern?.name,
          direction: result.direction, entry: result.entry?.toFixed(5),
          sl: result.sl?.toFixed(5), tp: result.tp?.toFixed(5),
          slPips: result.slPips, tpPips: result.tpPips,
          riskAmount: result.riskAmount, accountSize,
        }),
      });
      const data = await res.json();
      setAiComment(data.commentary || "No commentary returned.");
    } catch {
      setAiComment("AI commentary unavailable. Check your API key in Vercel environment variables.");
    }
    setAiLoading(false);
  };

  const scanAllPairs = async () => {
    setScanning(true); setScanResults([]);
    await new Promise(r => setTimeout(r, 400));
    const results = PAIRS.map(pair => {
      const trend = Math.random() > 0.5 ? "bull" : "bear";
      return analyzeFalcon(pair, generateCandles(pair, trend), accountSize, riskPct);
    }).sort((a, b) => b.score - a.score);
    setScanResults(results); setScanning(false);
  };

  const logTrade = () => {
    if (!analysis) return;
    setJournal(j => [...j, {
      pair: analysis.pair, direction: analysis.direction,
      entry: analysis.entry, sl: analysis.sl, tp: analysis.tp,
      lotSize: analysis.lotSize, riskAmount: analysis.riskAmount,
      score: analysis.score, result: null, pnl: null,
      time: new Date().toLocaleTimeString(),
    }]);
    setTab("journal");
  };

  return (
    <div style={{ minHeight: "100vh", background: "#040b04", color: "#c8e6c8", fontFamily: "'Courier New', monospace" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(90deg,#040b04,#071507,#040b04)", borderBottom: "1px solid #0f2a0f", padding: "18px 28px", display: "flex", alignItems: "center", gap: 16 }}>
        <div style={{ width: 36, height: 36, background: "linear-gradient(135deg,#00f5c4,#4ade80)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.2rem" }}>🦅</div>
        <div>
          <div style={{ fontSize: "0.55rem", letterSpacing: "0.35em", color: "#2a6a2a" }}>AI-POWERED SYSTEM</div>
          <div style={{ fontSize: "1.1rem", color: "#fff", fontWeight: "bold", letterSpacing: "0.1em" }}>FALCON STRATEGY ANALYZER</div>
        </div>
        <div style={{ marginLeft: "auto", textAlign: "right" }}>
          <div style={{ fontSize: "0.5rem", color: "#2a4a2a", letterSpacing: "0.2em" }}>ACCOUNT</div>
          <div style={{ fontSize: "0.9rem", color: "#00f5c4" }}>${accountSize.toLocaleString()}</div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #0f2a0f", background: "#030903" }}>
        {[["analyzer","📊 ANALYZER"],["scanner","🔍 SCANNER"],["journal",`📓 JOURNAL (${journal.length})`],["settings","⚙️ SETTINGS"]].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} style={{ background: tab===id?"#071507":"transparent", border:"none", borderBottom: tab===id?"2px solid #00f5c4":"2px solid transparent", color: tab===id?"#00f5c4":"#2a5a2a", padding:"14px 24px", cursor:"pointer", fontSize:"0.65rem", letterSpacing:"0.12em", fontFamily:"inherit" }}>{label}</button>
        ))}
      </div>

      <div style={{ padding: "28px 32px", maxWidth: 900, margin: "0 auto" }}>

        {/* ANALYZER */}
        {tab === "analyzer" && (
          <div>
            <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
              <select value={selectedPair} onChange={e => setSelectedPair(e.target.value)} style={{ background:"#071507", border:"1px solid #1a3a1a", color:"#00f5c4", padding:"10px 16px", fontSize:"0.8rem", fontFamily:"inherit", cursor:"pointer", borderRadius:2 }}>
                {PAIRS.map(p => <option key={p}>{p}</option>)}
              </select>
              <button onClick={() => runAnalysis(selectedPair)} disabled={scanning} style={{ background: scanning?"#071507":"linear-gradient(135deg,#00f5c4,#4ade80)", border:"none", color: scanning?"#2a5a2a":"#040b04", padding:"10px 28px", fontSize:"0.75rem", fontFamily:"inherit", cursor: scanning?"not-allowed":"pointer", fontWeight:"bold", letterSpacing:"0.1em", borderRadius:2 }}>
                {scanning ? "⟳ ANALYZING..." : "▶ RUN ANALYSIS"}
              </button>
            </div>

            {analysis && (
              <div>
                <div style={{ background:`${verdictColor(analysis.verdict)}15`, border:`1px solid ${verdictColor(analysis.verdict)}`, padding:"18px 24px", borderRadius:4, marginBottom:20, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div>
                    <div style={{ fontSize:"0.55rem", letterSpacing:"0.3em", color:verdictColor(analysis.verdict), marginBottom:4 }}>FALCON VERDICT</div>
                    <div style={{ fontSize:"1.4rem", color:"#fff", fontWeight:"bold" }}>{analysis.verdict}</div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontSize:"0.55rem", color:"#3a6a3a", marginBottom:4 }}>SETUP SCORE</div>
                    <div style={{ fontSize:"2rem", color:verdictColor(analysis.verdict), fontWeight:"bold" }}>{analysis.score}<span style={{ fontSize:"0.8rem" }}>/100</span></div>
                  </div>
                </div>

                <div style={{ display:"grid", gridTemplateColumns:"340px 1fr", gap:16, marginBottom:16 }}>
                  <div>
                    <div style={{ fontSize:"0.55rem", letterSpacing:"0.2em", color:"#2a5a2a", marginBottom:8 }}>{analysis.pair} — SIMULATED 1H CHART</div>
                    <MiniChart candles={generateCandles(analysis.pair, analysis.bullTrend?"bull":"bear")} ema50={analysis.ema50} ema200={analysis.ema200} entry={analysis.entry} sl={analysis.sl} tp={analysis.tp} />
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
                    <div style={{ fontSize:"0.55rem", letterSpacing:"0.2em", color:"#2a5a2a", marginBottom:2 }}>SIGNAL BREAKDOWN</div>
                    {analysis.signals.map((s, i) => (
                      <div key={i} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 14px", background: s.ok?"#4ade8008":"#f8717108", border:`1px solid ${s.ok?"#4ade8030":"#f8717130"}`, borderRadius:3 }}>
                        <span style={{ fontSize:"0.75rem" }}>{s.ok?"✓":"✗"}</span>
                        <span style={{ fontSize:"0.72rem", color: s.ok?"#4ade80":"#f87171" }}>{s.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12, marginBottom:16 }}>
                  {[
                    ["DIRECTION", analysis.direction, analysis.direction==="BUY"?"#4ade80":"#f87171"],
                    ["ENTRY PRICE", analysis.entry?.toFixed(5), "#fde047"],
                    ["STOP LOSS", analysis.sl?.toFixed(5), "#f87171"],
                    ["TAKE PROFIT", analysis.tp?.toFixed(5), "#00f5c4"],
                    ["SL PIPS", analysis.slPips, "#c8e6c8"],
                    ["TP PIPS (1:2)", analysis.tpPips, "#c8e6c8"],
                    ["LOT SIZE", analysis.lotSize+" lots", "#7ed6f7"],
                    ["RISK AMOUNT", "$"+analysis.riskAmount, "#f87171"],
                    ["POTENTIAL WIN", "$"+(parseFloat(analysis.riskAmount)*2).toFixed(2), "#4ade80"],
                  ].map(([l,v,c]) => (
                    <div key={l} style={{ background:"#071507", border:"1px solid #0f2a0f", padding:"14px 16px", borderRadius:3 }}>
                      <div style={{ fontSize:"0.5rem", letterSpacing:"0.2em", color:"#2a5a2a", marginBottom:6 }}>{l}</div>
                      <div style={{ fontSize:"0.9rem", color:c, fontWeight:"bold" }}>{v}</div>
                    </div>
                  ))}
                </div>

                <div style={{ background:"#04100a", border:"1px solid #0f3a1a", borderLeft:"3px solid #00f5c4", padding:"18px 20px", borderRadius:"0 4px 4px 0", marginBottom:16 }}>
                  <div style={{ fontSize:"0.55rem", letterSpacing:"0.25em", color:"#00f5c4", marginBottom:10 }}>🤖 AI ANALYST COMMENTARY</div>
                  {aiLoading
                    ? <div style={{ color:"#2a6a4a", fontSize:"0.78rem", fontStyle:"italic" }}>Analyzing market conditions...</div>
                    : <div style={{ color:"#8aaa8a", fontSize:"0.8rem", lineHeight:1.8 }}>{aiComment}</div>
                  }
                </div>

                {analysis.verdict !== "NO TRADE" && (
                  <button onClick={logTrade} style={{ width:"100%", background:"linear-gradient(90deg,#071507,#0f2a0f)", border:"1px solid #4ade80", color:"#4ade80", padding:14, fontSize:"0.75rem", fontFamily:"inherit", cursor:"pointer", letterSpacing:"0.15em", borderRadius:3 }}>
                    📓 LOG THIS TRADE TO JOURNAL
                  </button>
                )}
              </div>
            )}

            {!analysis && !scanning && (
              <div style={{ textAlign:"center", padding:"60px 20px", color:"#2a5a2a" }}>
                <div style={{ fontSize:"3rem", marginBottom:16 }}>🦅</div>
                <div style={{ fontSize:"0.8rem", letterSpacing:"0.2em" }}>SELECT A PAIR AND RUN ANALYSIS</div>
              </div>
            )}
          </div>
        )}

        {/* SCANNER */}
        {tab === "scanner" && (
          <div>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:24 }}>
              <div style={{ fontSize:"0.7rem", color:"#3a6a3a", letterSpacing:"0.15em" }}>SCAN ALL {PAIRS.length} MAJOR PAIRS</div>
              <button onClick={scanAllPairs} disabled={scanning} style={{ background: scanning?"transparent":"linear-gradient(135deg,#00f5c4,#4ade80)", border: scanning?"1px solid #2a5a2a":"none", color: scanning?"#2a5a2a":"#040b04", padding:"10px 24px", fontSize:"0.7rem", fontFamily:"inherit", cursor: scanning?"not-allowed":"pointer", fontWeight:"bold", letterSpacing:"0.1em", borderRadius:2 }}>
                {scanning ? "⟳ SCANNING..." : "🔍 SCAN ALL PAIRS"}
              </button>
            </div>
            {scanResults.map((r, i) => (
              <div key={r.pair} onClick={() => { setSelectedPair(r.pair); setTab("analyzer"); runAnalysis(r.pair); }} style={{ background:"#071507", border:`1px solid ${r.score>=80?"#4ade8040":r.score>=60?"#fde04740":"#1a2a1a"}`, padding:"18px 20px", borderRadius:4, display:"flex", alignItems:"center", gap:20, cursor:"pointer", marginBottom:10 }}>
                <div style={{ width:28, height:28, borderRadius:"50%", background:"#0f2a0f", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"0.7rem", color:"#2a6a2a", fontWeight:"bold" }}>#{i+1}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:"1rem", color:"#fff", fontWeight:"bold" }}>{r.pair}</div>
                  <div style={{ fontSize:"0.65rem", color:"#3a6a3a", marginTop:2 }}>{r.trendDir} · {r.pattern?.name||"No pattern"}</div>
                </div>
                <div style={{ textAlign:"center", width:60 }}>
                  <div style={{ fontSize:"0.5rem", color:"#3a5a3a", marginBottom:2 }}>DIR</div>
                  <div style={{ fontSize:"0.8rem", color: r.direction==="BUY"?"#4ade80":"#f87171", fontWeight:"bold" }}>{r.direction}</div>
                </div>
                <div style={{ textAlign:"center", width:60 }}>
                  <div style={{ fontSize:"0.5rem", color:"#3a5a3a", marginBottom:2 }}>SCORE</div>
                  <div style={{ fontSize:"1.2rem", color:verdictColor(r.verdict), fontWeight:"bold" }}>{r.score}</div>
                </div>
                <div style={{ padding:"6px 14px", background:`${verdictColor(r.verdict)}15`, border:`1px solid ${verdictColor(r.verdict)}40`, borderRadius:2, fontSize:"0.6rem", color:verdictColor(r.verdict), letterSpacing:"0.1em", minWidth:110, textAlign:"center" }}>{r.verdict}</div>
                <div style={{ fontSize:"0.6rem", color:"#2a5a2a" }}>ANALYZE →</div>
              </div>
            ))}
            {scanResults.length===0 && !scanning && (
              <div style={{ textAlign:"center", padding:"60px 20px", color:"#2a5a2a" }}>
                <div style={{ fontSize:"3rem", marginBottom:16 }}>🔍</div>
                <div style={{ fontSize:"0.8rem", letterSpacing:"0.2em" }}>CLICK SCAN TO FIND SETUPS</div>
              </div>
            )}
          </div>
        )}

        {tab === "journal" && <Journal journal={journal} setJournal={setJournal} />}

        {tab === "settings" && (
          <div style={{ maxWidth:480 }}>
            {[["ACCOUNT SIZE ($)", accountSize, setAccountSize, 100, 100000, 100], ["RISK PER TRADE (%)", riskPct, setRiskPct, 0.5, 3, 0.5]].map(([label, value, setter, min, max, step]) => (
              <div key={label} style={{ background:"#071507", border:"1px solid #0f2a0f", padding:20, borderRadius:4, marginBottom:16 }}>
                <div style={{ fontSize:"0.6rem", letterSpacing:"0.2em", color:"#3a6a3a", marginBottom:12 }}>{label}</div>
                <div style={{ fontSize:"1.4rem", color:"#00f5c4", marginBottom:12, fontWeight:"bold" }}>{value}{label.includes("%")?"%":""}</div>
                <input type="range" min={min} max={max} step={step} value={value} onChange={e => setter(parseFloat(e.target.value))} style={{ width:"100%", accentColor:"#00f5c4" }} />
              </div>
            ))}
            <div style={{ background:"#071507", border:"1px solid #0f2a0f", padding:20, borderRadius:4 }}>
              <div style={{ fontSize:"0.6rem", color:"#3a6a3a", letterSpacing:"0.2em", marginBottom:12 }}>RISK SUMMARY</div>
              {[["Max risk per trade", `$${(accountSize*riskPct/100).toFixed(2)}`], ["Potential win (1:2)", `$${(accountSize*riskPct/100*2).toFixed(2)}`], ["Suggested min account", "$500"]].map(([k,v]) => (
                <div key={k} style={{ display:"flex", justifyContent:"space-between", fontSize:"0.75rem", marginBottom:8 }}>
                  <span style={{ color:"#4a7a4a" }}>{k}</span>
                  <span style={{ color:"#c8e6c8" }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
