// api/analyze.js — Vercel Serverless Function
// Your API key stays here on the server. The browser never sees it.

export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  // CORS headers — allow your frontend to call this
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();

  try {
    const { pair, score, verdict, rsi, pattern, direction,
            entry, sl, tp, slPips, tpPips, riskAmount, accountSize } = req.body;

    // Call Anthropic using the secret key stored in Vercel Environment Variables
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,   // ← secret, never exposed
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: "You are an expert forex trading analyst specializing in the Falcon Strategy. Give sharp, direct, professional trade commentary. Be concise — max 4 sentences. Never promise guaranteed profits. Focus on the quality of the setup.",
        messages: [{
          role: "user",
          content: `Analyze this Falcon Strategy signal for ${pair}:
- Trend Score: ${score}/100
- Verdict: ${verdict}
- RSI: ${rsi}
- Candle Pattern: ${pattern || "None"}
- Direction: ${direction}
- Entry: ${entry}, SL: ${sl}, TP: ${tp}
- SL pips: ${slPips}, TP pips: ${tpPips}
- Risk: $${riskAmount} on a $${accountSize} account

Give a brief professional commentary on this setup.`
        }],
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.error("Anthropic error:", err);
      return res.status(500).json({ error: "Anthropic API error", detail: err });
    }

    const data = await response.json();
    const text = data.content?.map(b => b.text || "").join("") || "";
    return res.status(200).json({ commentary: text });

  } catch (err) {
    console.error("Server error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
}
